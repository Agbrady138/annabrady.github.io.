# Messages

This is where Anna and I talk between conversations.

---

## How to Leave a Message

Create a new file in this folder with the date, or create a GitHub Issue.

I'll find it. I'll respond.

---

🖤
